import rclpy
from rclpy.node import Node


class TimerNode(Node):
    """2초 ~ 3초 타이머 실행  노드"""

    def __init__(self):
        """노드를 생성 후 카운터와 타이머 초기화"""
        super().__init__("timer_node")

        # 두 타이머가 사용할 클래스
        self.counter = 0

        # 2초마다 함수 호출
        self.timer_2_seconds = self.create_timer(
            2.0,
            self.timer_2_seconds_callback,
        )

        # 3초마다 함수 호출
        self.timer_3_seconds = self.create_timer(
            3.0,
            self.timer_3_seconds_callback,
        )

    def timer_2_seconds_callback(self):
        """2초마다 카운터 1 증가시키고 로그 출력"""
        self.counter += 1

        self.get_logger().info(
            f"2 seconds passed : {self.counter}"
        )

    def timer_3_seconds_callback(self):
        """3초마다 카운터 1 감소시키고 로그 출력"""
        self.counter -= 1

        self.get_logger().info(
            f"3 seconds passed : {self.counter}"
        )


def main(args=None):
    """ROS2를 초기화 + timer_node 실행"""
    rclpy.init(args=args)

    timer_node = TimerNode()

    try:
        # 노드를 계속 실행 + 타이머 콜백을 처리
        rclpy.spin(timer_node)
    except KeyboardInterrupt:
        # Ctrl+C 종료
        pass
    finally:
        # 실행 환경 정리
        timer_node.destroy_node()
        rclpy.shutdown()
        
        # ros2 실행 중이면 종료
        if rclpy.ok():
          rclpy.shutdown()


if __name__ == "__main__":
    main()
