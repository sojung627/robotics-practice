import rclpy
from rclpy.node import Node


class LoggingNode(Node):
    """노드 이름 INFO 로그로 출력"""

    def __init__(self):
        super().__init__('logging_node')

        # 현재 노드 가져와 INFO 로그 출력
        node_name = self.get_name()
        self.get_logger().info(f'노드 이름: {node_name}')


def main(args=None):
    """노드를 초기화하고 실행 상태를 유지"""

    # ROS2 Python 통신 시스템 초기화
    rclpy.init(args=args)

    # LoggingNode 클래스 객체 생성
    logging_node = LoggingNode()

    try:
        # 노드 실행 상태를 유지
        # 콜백 들어오면 처리 위해 대기
        rclpy.spin(logging_node)

    except KeyboardInterrupt:
        # 종료했을 때 안내 로그
        logging_node.get_logger().info('logging_node를 종료합니다.')

    finally:
        # 노드가 사용한 자원을 정리
        logging_node.destroy_node()

        # 통신 시스템을 종료한다.
        rclpy.shutdown()


if __name__ == '__main__':
    main()
